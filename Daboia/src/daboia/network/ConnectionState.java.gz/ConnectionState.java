
package daboia.network;

public enum ConnectionState {
    UNDEFINED,
    CONNECTION_ESTABLISHED,
    CONNECTION_ENDED;
}
