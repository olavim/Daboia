
package daboia.ui.button;

public enum ButtonState {
    DEFAULT,
    HOVER,
    DOWN;
}
