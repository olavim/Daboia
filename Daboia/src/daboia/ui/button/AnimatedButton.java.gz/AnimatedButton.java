
package daboia.ui.button;

public interface AnimatedButton {
    
    void showAnimation();
    void hideAnimation();

}
