
package daboia;

public class LaunchException extends Exception {

    public LaunchException(String error) {
        super(error);
    }
    
}
