daboia.algorithm.Location
daboia.algorithm.SnakeLogicUtils
daboia.algorithm.Berserk
